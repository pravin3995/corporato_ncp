$('.slideshow').slick({
  infinite: true,
  autoplay: true,
  dots: true,
  arrows: true,
  autoplaySpeed: 4000
});